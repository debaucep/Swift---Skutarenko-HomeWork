import UIKit

var greeting = "Hello, playground"

//
//// basic types
//
//var a: Int = 10
//var b: Float = 11.1
//var c: Double = 12.2
//
//var sumABCINt = a + Int (b) + Int (c)
//var sumABCFloat = Float (a) + b + Float (c)
//var sumABCDouble = Double (a) + Double (b) + c
//
//
//Double (sumABCINt) <  sumABCDouble
//
//// tuples
//
//
//

/*
 
 Домашнее задание:

 1. Создать тюпл с тремя параметрами:

 - максимальное количество отжиманий maxpressup
 - максимальное количество подтягиваний maxpullup
 - максимальное количество приседаний maxsitdowns

 Заполните его своими достижениями :)

 Распечатайте его через println()

 2. Также сделайте три отдельных вывода в консоль для каждого параметра

 При том одни значения доставайте по индексу, а другие по параметру

 3. Создайте такой же тюпл для другого человека (супруги или друга)

 с такими же параметрами, но с другими значениями

 Используйте промежуточную переменную чтобы поменять соответствующие значения

 первого тюпла на значения второго

 4. Создайте третий тюпл с теми же параметрами, но значения это разница

 между соответствующими значениями первого и второго тюплов

 Результат выведите в консоль
 
 */


////1
//var mySportRecords = (maxpressup: 100, maxpullup: 30, maxsitdowns: 100)
//
//mySportRecords.maxpressup
//mySportRecords.maxpullup
//mySportRecords.maxsitdowns
//
//print ("My resutls are: Max nr of maxpressup: \(mySportRecords.maxpressup), max nr of pullups: \(mySportRecords.maxpullup) , max nr of sitdowns: \(mySportRecords.maxsitdowns) ")
//
////2
//
//print ("Nr of pressup \(mySportRecords.maxpressup)")
//print ("Nr of pullups \(mySportRecords.1)")
//print ("Nr of sitdowns \(mySportRecords.maxsitdowns)")
//
//
//
////3
//
//var zavrSportRecords = (maxpressup: 20, maxpullup: 15, maxsitdowns: 50)
//
//
//zavrSportRecords.maxpressup
//zavrSportRecords.maxpullup
//zavrSportRecords.maxsitdowns
//
////4
// 
//var pressupsdiff = (mySportRecords.maxpressup - zavrSportRecords.maxpressup )
//var pullupsdiff = (mySportRecords.maxpullup - zavrSportRecords.maxpullup)
//var sitdownsdiff = (mySportRecords.maxsitdowns - zavrSportRecords.maxsitdowns)
//
//var tuplediff = (pressups: pressupsdiff, pullups: pullupsdiff, sitdowns: sitdownsdiff)
//
//print (tuplediff)
//
//


//Swift 4. The Basics (Optionals)

/*
 
1. Создать пять строковых констант

Одни константы это только цифры, другие содержат еще и буквы

Найти сумму всех этих констант приведя их к Int

(Используйте и optional binding и forced unwrapping)

2. С сервера к нам приходит тюпл с тремя параметрами:

statusCode, message, errorMessage (число, строка и строка)

в этом тюпле statusCode всегда содержит данные, но сама строка приходит только в одном поле

если statusCode от 200 до 300 исключительно, то выводите message,

в противном случает выводите errorMessage

После этого проделайте тоже самое только без участия statusCode

3. Создайте 5 тюплов с тремя параметрами:

имя, номер машины, оценка за контрольную

при создании этих тюплов не должно быть никаких данных

после создания каждому студенту установите имя

некоторым установите номер машины

некоторым установите результат контрольной

выведите в консоль:

- имена студента
- есть ли у него машина
- если да, то какой номер
- был ли на контрольной
- если да, то какая оценка
 
 */



//
//1. Создать пять строковых констант
//
//Одни константы это только цифры, другие содержат еще и буквы
//
//Найти сумму всех этих констант приведя их к Int
//
//(Используйте и optional binding и forced unwrapping)


//1

let a = "10"
let b = "A"
let c = "32"
let d = "2"
let e = "C"


//Для того, чтобы сложить нужно все константы перевести в Инт. Те, которые содержать только цифры, в ИНТ перейдет, другие же - дадут нил


var safeA = 0, safeB = 0, safeC = 0, safeD = 0, safeE = 0


//if let tmp1 = testNr1, let tmp2 = testNr2 {
//    safeTestNr1 = tmp1
//    safeTestNr2 = tmp2
//}



if let tmp = Int(a) {
    safeA = tmp
}

safeA

if let tmp = Int(b) {
    safeB = tmp
}


if Int(c) != nil {
    safeC = Int(c)!
}


if Int(d) != nil {
    safeD = Int(d)!
}

if Int(e) != nil {
    safeE = Int(e)!
}


var sumABCDE = safeA + safeB + safeC + safeD + safeE




//2. С сервера к нам приходит тюпл с тремя параметрами:
//
//statusCode, message, errorMessage (число, строка и строка)
//
//в этом тюпле statusCode всегда содержит данные, но сама строка приходит только в одном поле
//
//если statusCode от 200 до 300 исключительно, то выводите message,
//
//в противном случает выводите errorMessage
//
//После этого проделайте тоже самое только без участия statusCode


var tuple3: (Int, String)

var serverAnswer: (statusCode: Int, message: String?, error: String?) = (statusCode: 413, message: "The program works fine", error: "Error message here")

serverAnswer.1


//Examples

//(statusCode: 213, message: "All Fine", error: nil)
//(statusCode: 404, message: nil , error: "Not found")


if serverAnswer.0 > 200 && serverAnswer.0 < 300 {
    print (serverAnswer.1!)
} else {
    print (serverAnswer.2!)
}


var serverAnswer2: (message: String?, error: String?) = (message: nil , error: "Some Error")

serverAnswer2.0
serverAnswer2.1


if let tmp = serverAnswer2.0 {
    print (tmp)
} else {
    print (serverAnswer2.1!)
}


/*
3. Создайте 5 тюплов с тремя параметрами:

имя, номер машины, оценка за контрольную

при создании этих тюплов не должно быть никаких данных

после создания каждому студенту установите имя

некоторым установите номер машины

некоторым установите результат контрольной

выведите в консоль:

- имена студента
- есть ли у него машина
- если да, то какой номер
- был ли на контрольной
- если да, то какая оценка
 
*/

var student1: (name: String?, carNumber: String?, mark: Double?)
var student2: (name: String?, carNumber: String?, mark: Double?)
var student3: (name: String?, carNumber: String?, mark: Double?)
var student4: (name: String?, carNumber: String?, mark: Double?)
var student5: (name: String?, carNumber: String?, mark: Double?)



var testTpl = (1, 2)
testTpl.0
testTpl.1

type(of: testTpl)

//names

student1.name = "Vasya"
student2.name = "Petia"
student3.name = "Ivan"
student4.name = "Nikolay"
student5.name = "Alex"

//cars

student1.carNumber = "Car1"
student4.carNumber = "Car4"


// marks

student1.mark = 5.0
student2.mark = 4.2
student3.mark = 3.2
student4.mark = 4.6
